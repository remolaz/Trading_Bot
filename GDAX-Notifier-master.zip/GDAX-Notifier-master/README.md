I have only tested this on Ubuntu on a server with mail correctly set up
This depends on the gdax trading toolkit

npm install -g gdax-trading-toolkit
npm install -g commander

After you give it your GDAX api key information
It can be run with node fill.js

